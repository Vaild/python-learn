#!/usr/bin/python3
# coding=utf-8

message = None


def send():
    print('I am send')


if __name__ == '__main__':
    send()
    print(message)
