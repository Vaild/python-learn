#!/usr/bin/python3
# coding=utf-8

from send_message import message


def receive():
    print('I am receive')


if __name__ == '__main__':
    receive()
